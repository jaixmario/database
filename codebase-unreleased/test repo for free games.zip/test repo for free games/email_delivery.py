import json
import os
import re
import smtplib
import time
from datetime import datetime, timezone
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import requests


SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
CONFIG_FILE = "config.json"
EMAILJS_API_URL = "https://api.emailjs.com/api/v1.0/email/send"
EMAIL_RATE_STATE_FILE = "email-rate-state.json"
SUPPORTED_EMAIL_PROVIDERS = {"gmail", "emailjs"}


def parse_csv_values(value):
    return [item.strip() for item in str(value).split(",") if item.strip()]


def strip_html_tags(value):
    text = re.sub(r"(?is)<(script|style).*?>.*?</\1>", "", value or "")
    text = re.sub(r"(?s)<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def normalize_email_provider(value):
    provider = str(value or "gmail").strip().lower()
    return provider if provider in SUPPORTED_EMAIL_PROVIDERS else "gmail"


def normalize_safe_rate_seconds(value, fallback):
    try:
        return max(0, int(value))
    except Exception:
        return fallback


def load_config():
    default_config = {
        "secrets": {
            "use_hardcoded_secrets": False,
            "secrets_file": "secrets.json",
        },
        "notifications": {
            "email": True,
            "telegram": True,
            "discord": True,
        },
        "email": {
            "provider": "gmail",
            "safe_rate_seconds": {
                "gmail": 5,
                "emailjs": 2,
            },
        },
    }

    if not os.path.exists(CONFIG_FILE):
        return default_config

    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as file:
            data = json.load(file)
    except Exception:
        return default_config

    secrets = data.get("secrets", {})
    notifications = data.get("notifications", {})
    email = data.get("email", {})
    return {
        "secrets": {
            "use_hardcoded_secrets": bool(secrets.get("use_hardcoded_secrets", False)),
            "secrets_file": str(secrets.get("secrets_file", "secrets.json")),
        },
        "notifications": {
            "email": bool(notifications.get("email", True)),
            "telegram": bool(notifications.get("telegram", True)),
            "discord": bool(notifications.get("discord", True)),
        },
        "email": {
            "provider": normalize_email_provider(email.get("provider", "gmail")),
            "safe_rate_seconds": {
                "gmail": normalize_safe_rate_seconds(
                    (email.get("safe_rate_seconds", {}) or {}).get("gmail", 5),
                    5,
                ),
                "emailjs": normalize_safe_rate_seconds(
                    (email.get("safe_rate_seconds", {}) or {}).get("emailjs", 2),
                    2,
                ),
            },
        },
    }


def load_rate_state():
    if not os.path.exists(EMAIL_RATE_STATE_FILE):
        return {}

    try:
        with open(EMAIL_RATE_STATE_FILE, "r", encoding="utf-8") as file:
            data = json.load(file)
    except Exception:
        return {}

    return data if isinstance(data, dict) else {}


def save_rate_state(data):
    with open(EMAIL_RATE_STATE_FILE, "w", encoding="utf-8") as file:
        json.dump(data, file, indent=2)


def apply_safe_rate(config, provider):
    safe_rate = int((config.get("email", {}).get("safe_rate_seconds", {}) or {}).get(provider, 0))
    if safe_rate <= 0:
        return

    state = load_rate_state()
    provider_state = state.get(provider, {}) if isinstance(state.get(provider, {}), dict) else {}
    last_sent_at = provider_state.get("last_sent_at")
    if last_sent_at:
        try:
            last_dt = datetime.fromisoformat(str(last_sent_at))
            now_dt = datetime.now(timezone.utc)
            elapsed = (now_dt - last_dt).total_seconds()
            remaining = safe_rate - elapsed
            if remaining > 0:
                print(f"Waiting {remaining:.1f}s to respect {provider} safe rate.")
                time.sleep(remaining)
        except Exception:
            pass


def mark_send_time(provider):
    state = load_rate_state()
    state[provider] = {
        "last_sent_at": datetime.now(timezone.utc).isoformat(),
    }
    save_rate_state(state)


def load_secrets(config):
    if config["secrets"]["use_hardcoded_secrets"]:
        secrets_file = config["secrets"]["secrets_file"]
        try:
            with open(secrets_file, "r", encoding="utf-8") as file:
                data = json.load(file)
        except Exception:
            data = {}

        email_data = data.get("email", {})
        telegram_data = data.get("telegram", {})
        discord_data = data.get("discord", {})
        return {
            "EMAIL": str(email_data.get("email", email_data.get("gmail_email", ""))),
            "PASSWORD": str(email_data.get("password", email_data.get("gmail_password", ""))),
            "TO_EMAIL": str(email_data.get("to_email", "")),
            "EMAILJS_SERVICE_ID": str(email_data.get("emailjs_service_id", "")),
            "EMAILJS_TEMPLATE_ID": str(email_data.get("emailjs_template_id", "")),
            "EMAILJS_PUBLIC_KEY": str(email_data.get("emailjs_public_key", "")),
            "EMAILJS_PRIVATE_KEY": str(email_data.get("emailjs_private_key", "")),
            "EMAILJS_FROM_NAME": str(email_data.get("from_name", "Free Games Auto Notifier")),
            "TELEGRAM_BOT_TOKEN": str(telegram_data.get("bot_token", "")),
            "TELEGRAM_CHAT_ID": str(telegram_data.get("chat_id", "")),
            "DISCORD_BOT_TOKEN": str(discord_data.get("bot_token", "")),
            "DISCORD_CHANNEL_ID": str(discord_data.get("channel_id", "")),
        }

    return {
        "EMAIL": os.getenv("EMAIL", ""),
        "PASSWORD": os.getenv("PASSWORD", ""),
        "TO_EMAIL": os.getenv("TO_EMAIL", ""),
        "EMAILJS_SERVICE_ID": os.getenv("EMAILJS_SERVICE_ID", ""),
        "EMAILJS_TEMPLATE_ID": os.getenv("EMAILJS_TEMPLATE_ID", ""),
        "EMAILJS_PUBLIC_KEY": os.getenv("EMAILJS_PUBLIC_KEY", ""),
        "EMAILJS_PRIVATE_KEY": os.getenv("EMAILJS_PRIVATE_KEY", ""),
        "EMAILJS_FROM_NAME": os.getenv("EMAILJS_FROM_NAME", "Free Games Auto Notifier"),
        "TELEGRAM_BOT_TOKEN": os.getenv("TELEGRAM_BOT_TOKEN", ""),
        "TELEGRAM_CHAT_ID": os.getenv("TELEGRAM_CHAT_ID", ""),
        "DISCORD_BOT_TOKEN": os.getenv("DISCORD_BOT_TOKEN", ""),
        "DISCORD_CHANNEL_ID": os.getenv("DISCORD_CHANNEL_ID", ""),
    }


def send_gmail_email(secrets, subject, html):
    recipients = parse_csv_values(secrets["TO_EMAIL"])[:30]
    if not secrets["EMAIL"] or not secrets["PASSWORD"] or not recipients:
        return

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = secrets["EMAIL"]
    msg["To"] = ", ".join(recipients)
    msg.attach(MIMEText(html, "html"))

    with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
        server.starttls()
        server.login(secrets["EMAIL"], secrets["PASSWORD"])
        server.sendmail(secrets["EMAIL"], recipients, msg.as_string())


def send_emailjs_email(secrets, subject, html):
    recipients = parse_csv_values(secrets["TO_EMAIL"])
    if (
        not recipients
        or not secrets["EMAILJS_SERVICE_ID"]
        or not secrets["EMAILJS_TEMPLATE_ID"]
        or not secrets["EMAILJS_PUBLIC_KEY"]
    ):
        return

    payload = {
        "service_id": secrets["EMAILJS_SERVICE_ID"],
        "template_id": secrets["EMAILJS_TEMPLATE_ID"],
        "user_id": secrets["EMAILJS_PUBLIC_KEY"],
        "template_params": {
            "to_email": ", ".join(recipients),
            "subject": subject,
            "html_message": html,
            "message": strip_html_tags(html),
            "from_name": secrets["EMAILJS_FROM_NAME"],
        },
    }

    if secrets["EMAILJS_PRIVATE_KEY"]:
        payload["accessToken"] = secrets["EMAILJS_PRIVATE_KEY"]

    response = requests.post(
        EMAILJS_API_URL,
        json=payload,
        headers={"Content-Type": "application/json"},
        timeout=30,
    )
    if response.ok:
        return

    response_body = response.text.strip() or "No response body returned."
    raise RuntimeError(
        "EmailJS send failed with "
        f"HTTP {response.status_code}: {response_body}. "
        "Check EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, EMAILJS_PUBLIC_KEY, "
        "EMAILJS_PRIVATE_KEY, and your EmailJS template field mappings."
    )


def send_email(config, secrets, subject, html):
    if not config["notifications"]["email"]:
        return

    provider = normalize_email_provider(config["email"]["provider"])
    apply_safe_rate(config, provider)
    if provider == "emailjs":
        send_emailjs_email(secrets, subject, html)
        mark_send_time(provider)
        return

    send_gmail_email(secrets, subject, html)
    mark_send_time(provider)
