﻿# Free Games Auto Notifier

> Automatically tracks **Epic Games** and **Steam** free game offers and sends you a beautiful HTML email notification whenever new free games appear â€” powered by GitHub Actions.

![Python](https://img.shields.io/badge/Python-3.11-blue?logo=python&logoColor=white)
![GitHub Actions](https://img.shields.io/badge/GitHub%20Actions-Automated-success?logo=github-actions&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-green)
![Schedule](https://img.shields.io/badge/Runs%20Every-6%20Hours-orange?logo=clockify&logoColor=white)
![Telegram](https://img.shields.io/badge/Telegram-Bot-26A5E4?logo=telegram&logoColor=white)
![Discord](https://img.shields.io/badge/Discord-Bot-5865F2?logo=discord&logoColor=white)

<!-- README_AUTO_SECTION:START -->
## Free Games Right Now

Last updated: **18 Apr 2026, 06:27 PM IST**  
Source: Epic fallback from saved state, Steam live data

### Epic Games
- **The Stone of Madness** - free until `23 Apr 2026, 08:30 PM IST` ([Claim](https://store.epicgames.com/en-US/p/the-stone-of-madness-7b22f3))

### Upcoming on Epic
- **DOOMBLADE** - starts `23 Apr 2026, 08:30 PM IST` ([Store page](https://store.epicgames.com/en-US/p/doomblade-afdf9a))

### Steam
- **Cthulhu: The Cosmic Abyss - Sanity Skin Pack** - Free to Keep ([Open](https://store.steampowered.com/app/4277070/Cthulhu_The_Cosmic_Abyss__Sanity_Skin_Pack/?snr=1_7_7_2300_150_1))
- **Legend of Keepers: Career of a Dungeon Manager** - Free to Keep ([Open](https://store.steampowered.com/app/978520/Legend_of_Keepers_Career_of_a_Dungeon_Manager/?snr=1_7_7_2300_150_1))
- **NineHells** - Free to Keep ([Open](https://store.steampowered.com/app/2860410/NineHells/?snr=1_7_7_2300_150_1))
- **Stickman Killing Zombie** - Free to Keep ([Open](https://store.steampowered.com/app/2792610/Stickman_Killing_Zombie/?snr=1_7_7_2300_150_1))
- **Uncanny Tales: Cold Road** - Free to Keep ([Open](https://store.steampowered.com/app/3534240/Uncanny_Tales_Cold_Road/?snr=1_7_7_2300_150_1))
<!-- README_AUTO_SECTION:END -->

---

## Features

- Epic Games support for current and upcoming free promotions
- Steam support for free-to-keep deals and free weekend events
- HTML email notifications through Gmail SMTP or EmailJS
- Telegram bot notifications with per-game photo cards
- **Discord bot notifications with rich embeds** (title, image, dates, store link)
- Change detection to avoid duplicate notifications
- Automatic README refresh on every scheduled workflow run
- GitHub Actions automation every 6 hours

---

## Project Structure

```text
free-games-notifier/
|-- epic.PY
|-- steam.py
|-- start.py
|-- generate_readme.py
|-- config.json
|-- secrets.json
|-- email-rate-state.json
|-- free.json
|-- free-steam.json
|-- index.html
|-- templates/
|   |-- emailjs-template.html
|   `-- emailjs-template-setup.txt
|-- SITE/
|   |-- docs.html
|   |-- site.css
|   `-- site.js
`-- .github/
    `-- workflows/
        `-- main.yml
```

---

## Getting Started

### 1. Clone the repository

```bash
git clone https://github.com/your-username/free-games-notifier.git
cd free-games-notifier
```

### 2. Install dependencies

```bash
pip install requests beautifulsoup4
```

### 3. Add GitHub secrets

Create these repository secrets in `Settings -> Secrets and variables -> Actions`:

| Secret Name | Description |
|-------------|-------------|
| `EMAIL` | Sender Gmail address for `gmail` provider |
| `PASSWORD` | Gmail App Password for `gmail` provider |
| `TO_EMAIL` | Recipient email address or comma-separated email addresses |
| `EMAILJS_SERVICE_ID` | EmailJS service ID for `emailjs` provider |
| `EMAILJS_TEMPLATE_ID` | EmailJS template ID for `emailjs` provider |
| `EMAILJS_PUBLIC_KEY` | EmailJS public key |
| `EMAILJS_PRIVATE_KEY` | Optional EmailJS private key |
| `EMAILJS_FROM_NAME` | Optional sender name passed to EmailJS templates |
| `TELEGRAM_BOT_TOKEN` | Telegram bot token from BotFather |
| `TELEGRAM_CHAT_ID` | Telegram chat ID or comma-separated chat IDs |
| `DISCORD_BOT_TOKEN` | Discord bot token from the Developer Portal |
| `DISCORD_CHANNEL_ID` | Discord channel ID or comma-separated channel IDs |


Use a Gmail App Password, not your normal account password. If you prefer EmailJS, switch the provider in `config.json` and fill the EmailJS keys instead. Each notification type is independent â€” you can enable only the ones you need via `config.json`.

### 4. Control notification types with `config.json`

```json
{
  "secrets": {
    "use_hardcoded_secrets": false,
    "secrets_file": "secrets.json"
  },
  "notifications": {
    "email": true,
    "telegram": true,
    "discord": true
  },
  "email": {
    "provider": "gmail",
    "safe_rate_seconds": {
      "gmail": 5,
      "emailjs": 2
    }
  }
}
```


Set any value to `false` to skip that channel entirely â€” no credentials required for disabled channels. Set `email.provider` to `gmail` or `emailjs` to choose how emails are sent.

`email.safe_rate_seconds` adds a minimum wait between sends for each provider. This does not skip notifications; it only delays the next send when Epic and Steam both trigger close together.

### 5. Optional JSON secrets file

Set this in `config.json`:

```json
{
  "secrets": {
    "use_hardcoded_secrets": true,
    "secrets_file": "secrets.json"
  }
}
```

Then fill `secrets.json` with your local values:

```json
{
  "email": {
    "email": "you@gmail.com",
    "password": "your-app-password",
    "to_email": "first@example.com,second@example.com",
    "emailjs_service_id": "service_xxxxxx",
    "emailjs_template_id": "template_xxxxxx",
    "emailjs_public_key": "public_xxxxxxxxxxxx",
    "emailjs_private_key": "",
    "from_name": "Free Games Auto Notifier"
  },
  "telegram": {
    "bot_token": "123456:telegram-bot-token",
    "chat_id": "123456789"
  },
  "discord": {
    "bot_token": "YOUR_DISCORD_BOT_TOKEN",
    "channel_id": "YOUR_CHANNEL_ID"
  }
}
```

Email, Telegram, and Discord all support multiple targets separated by commas. Gmail delivery is capped at 30 recipients per run.

### 6. EmailJS template variables

When `email.provider` is set to `emailjs`, the notifier sends one EmailJS REST API request with these template params:

- `to_email`
- `subject`
- `html_message`
- `message`
- `from_name`

Your EmailJS template can use those variables in the recipient, subject, and body fields. A simple setup is to map the recipient field to `{{to_email}}`, the subject to `{{subject}}`, and the body content to `{{html_message}}`.

Copy-paste files are included in the repo:

- `templates/emailjs-template.html`
- `templates/emailjs-template-setup.txt`

Paste the HTML file into your EmailJS template editor in HTML/source mode. The template uses `{{{html_message}}}` so the notifier's HTML renders correctly.

---

## How It Works

### `epic.PY`

1. Calls the Epic Games promotions API.
2. Extracts current and upcoming free games.
3. Formats dates in IST.
4. Compares the latest JSON snapshot with `free.json`.
5. Sends email, Telegram, and/or Discord alerts only when the lineup changes.

### `steam.py`

1. Scrapes Steam search results for discounted free offers.
2. Checks Steam featured categories for free weekend events.
3. Compares the latest JSON snapshot with `free-steam.json`.
4. Sends email, Telegram, and/or Discord alerts only when the lineup changes.

#### Discord notifications

Both scripts post to Discord via the REST API (`POST /channels/{id}/messages`) using a bot token. Each run sends:

- A **summary message** with the total count of free games.
- One **rich embed per game** containing the title (linked to the store page), cover image, and relevant dates or offer type â€” colour-coded by category.

#### Telegram notifications

Both scripts send Telegram updates using the Bot API. Each run sends:

- A short **summary message**.
- One **formatted message or photo card per game** with clickable links.
- Delivery to one or many chats when `chat_id` contains comma-separated values.

### `generate_readme.py`

1. Fetches the latest Epic and Steam game data.
2. Rebuilds the auto-managed section at the top of this README.
3. Falls back to saved state files if a live fetch fails.

---

## GitHub Actions Workflow

The workflow runs on:

- Schedule: every 6 hours with `0 */6 * * *`
- Manual trigger: `workflow_dispatch`

Each run:

1. Installs dependencies.
2. Runs `epic.PY`.
3. Runs `steam.py`.
4. Runs `generate_readme.py`.
5. Commits updated state files and `README.md` if anything changed.

---

## Run Manually

Run both notifier scripts with one command:

```powershell
python start.py
```

If you want to run with custom environment variables locally:

```powershell
$env:EMAIL="you@gmail.com"
$env:PASSWORD="your-app-password"
$env:TO_EMAIL="first@example.com,second@example.com"
$env:EMAILJS_SERVICE_ID="service_xxxxxx"
$env:EMAILJS_TEMPLATE_ID="template_xxxxxx"
$env:EMAILJS_PUBLIC_KEY="public_xxxxxxxxxxxx"
$env:EMAILJS_PRIVATE_KEY=""
$env:EMAILJS_FROM_NAME="Free Games Auto Notifier"
$env:TELEGRAM_BOT_TOKEN="123456:telegram-bot-token"
$env:TELEGRAM_CHAT_ID="123456789"
$env:DISCORD_BOT_TOKEN="your-discord-bot-token"
$env:DISCORD_CHANNEL_ID="your-channel-id"

python start.py
python generate_readme.py
```

---

## Security Notes

- Credentials are never committed to the repository.
- Secrets are injected at runtime through GitHub Actions.
- `email-rate-state.json` stores the last successful send time for Gmail and EmailJS safe-rate delays.
- State files are JSON snapshots containing signatures plus game metadata like title, link, image, dates, and offer type.

---

## License

This project is open source and available under the [MIT License](LICENSE).
